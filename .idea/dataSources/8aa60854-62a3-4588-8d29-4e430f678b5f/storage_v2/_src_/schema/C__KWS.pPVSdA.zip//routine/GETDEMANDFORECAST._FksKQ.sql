create function getDemandForecast(time1 in timestamp, time2 in timestamp, g_id in number, p_days in number)
    return DemandForecast pipelined as
    v_row forecast;
    cur_day number := 1;
    days_count number := TO_DATE(to_char(time2, 'dd.MM.yyyy'), 'dd.MM.yyyy')-TO_DATE(to_char(time1, 'dd.MM.yyyy'), 'dd.MM.yyyy') + 1;
    type NumberArray is varray(365) of number;
    days_arr NumberArray := NumberArray();
    days_num NumberArray := NumberArray();
    tmp_arr NumberArray;
    tmp_arr1 NumberArray;
    ind number;
begin
    --INIT ARRAY OF DAYS
    --dbms_output.put_line('Days count: '||days_count);
    for r in (select TO_DATE(to_char(create_date, 'dd.MM.yyyy'),'dd.MM.yyyy') as "DATE", sum(good_count) as "COUNT" from sales
        where good_id = g_id and create_date between time1 and time2
        group by good_id, TO_DATE(to_char(create_date, 'dd.MM.yyyy'),'dd.MM.yyyy')
        order by TO_DATE(to_char(create_date, 'dd.MM.yyyy'),'dd.MM.yyyy')) loop
        while cur_day < (r.date - to_date(to_char(time1,'dd.MM.yyyy'),'dd.MM.yyyy')+1)
        loop
            days_arr.extend();
            days_arr(cur_day) := 0;
            days_num.extend();
            days_num(cur_day) := cur_day;
            cur_day:=cur_day+1;
        end loop;
        days_arr.extend();
        days_arr(cur_day) := r.count;
        days_num.extend();
        days_num(cur_day) := cur_day;
        cur_day:=cur_day+1;
        --dbms_output.put_line(r.date - to_date(to_char(time1,'dd.mm.yyyy'))+1||' '||r.count);
    end loop;
    while cur_day <= days_count
    loop
        days_arr.extend();
        days_arr(cur_day) := 0;
        days_num.extend();
        days_num(cur_day) := cur_day;
        cur_day:=cur_day+1;
    end loop;

    --dbms_output.put_line('ARRAY:');
    --for i in days_arr.first..days_arr.last loop
        --dbms_output.put_line(days_num(i)||' '||days_arr(i));
    --end loop;

    --dbms_output.put_line('TEST:');
    while (days_arr.last > 2)
    loop
        tmp_arr := NumberArray();
        tmp_arr1 := NumberArray();
        cur_day := 1;
        ind := 1;
        days_count := days_arr.last;
        while (cur_day <= days_count)
        loop
            if (cur_day = days_count) then
                tmp_arr.extend();
                tmp_arr(ind) := days_arr(days_count);
                tmp_arr1.extend();
                tmp_arr1(ind) := days_num(days_count);
                exit;
            end if;
            tmp_arr.extend();
            tmp_arr(ind) := (days_arr(cur_day) + days_arr(cur_day + 1))/2;
            tmp_arr1.extend();
            tmp_arr1(ind) := days_num(cur_day);
            cur_day := cur_day + 2;
            ind := ind + 1;
        end loop;
        days_arr := tmp_arr;
        days_num := tmp_arr1;

        --dbms_output.put_line('A');
        --for i in days_arr.first..days_arr.last loop
        --    dbms_output.put_line(days_num(i)||' '||days_arr(i));
        --end loop;
    end loop;

    --dbms_output.put_line('Line');
    for i in 1..p_days loop
        --dbms_output.put_line(i||' '||((days_arr(2)-days_arr(1))*(i-days_num(1))/(days_num(2)-days_num(1))+days_arr(1)));
        v_row := forecast(i, ((days_arr(2)-days_arr(1))*(i-days_num(1))/(days_num(2)-days_num(1))+days_arr(1)));
        pipe row (v_row);
    end loop;
    return;
end;
/

