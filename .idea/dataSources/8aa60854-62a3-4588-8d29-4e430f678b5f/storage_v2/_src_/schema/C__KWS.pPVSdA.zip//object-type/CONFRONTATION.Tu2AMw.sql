create type confrontation as object
("DATE" varchar2(12),
count1 number,
count2 number);
/

