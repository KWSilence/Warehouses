create function getGoodsMaxRequest(time1 in timestamp, time2 in timestamp) return number as
    res number;
begin
    select good_id into res from sales
    where create_date between time1 and time2
    group by good_id
    order by sum(good_count) desc
    fetch next 1 rows only;
    return(res);
end;
/

