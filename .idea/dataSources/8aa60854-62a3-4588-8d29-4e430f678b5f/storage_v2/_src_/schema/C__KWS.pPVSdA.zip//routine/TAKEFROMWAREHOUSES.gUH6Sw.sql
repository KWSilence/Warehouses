create procedure takeFromWarehouses(g_id in number, g_count number) is
    c1 number;
    c2 number;
    tmp number;
begin
    select coalesce(warehouse1.good_count,0), coalesce(warehouse2.good_count,0) into c1, c2 from goods
    left join warehouse1 on warehouse1.good_id=goods.id
    left join warehouse2 on warehouse2.good_id=goods.id
    where goods.id = g_id;

    if (c1+c2) >= g_count
    then
        if (c1 > g_count)
        then
            update warehouse1 set good_count = good_count - g_count where good_id = g_id;
        else
            tmp := g_count - c1;
            update warehouse1 set good_count = 0 where good_id = g_id;
            update warehouse2 set good_count = good_count - tmp where good_id = g_id;
        end if;
    end if;
end;
/

