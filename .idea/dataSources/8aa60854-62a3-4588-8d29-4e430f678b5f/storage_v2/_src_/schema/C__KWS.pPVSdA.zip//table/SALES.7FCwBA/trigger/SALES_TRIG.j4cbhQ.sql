create trigger SALES_TRIG
    before insert
    on SALES
    for each row
    when (NEW.ID IS NULL)
BEGIN
    SELECT SALES_SEQ.nextval INTO :NEW.ID FROM dual;
END;
/

