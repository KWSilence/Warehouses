create view VIEW1 as
select goods.id, goods.name, warehouse1.good_count from goods
join warehouse1 on goods.id = warehouse1.good_id
where good_count < 5
/

