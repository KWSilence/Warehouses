create trigger CHECKCOUNTFORSALES1
    before insert
    on SALES
    for each row
begin
    if :new.good_count < 1 then
        raise_application_error(-20200, 'good_count should not be less than 1');
    end if;
end;
/

