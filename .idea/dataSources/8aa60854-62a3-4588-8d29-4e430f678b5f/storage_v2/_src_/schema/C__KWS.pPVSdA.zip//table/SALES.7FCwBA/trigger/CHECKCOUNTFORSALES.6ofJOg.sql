create trigger CHECKCOUNTFORSALES
    before insert
    on SALES
    for each row
declare
    sum_count number;
begin
    select (coalesce(warehouse1.good_count,0)+coalesce(warehouse2.good_count,0)) into sum_count from goods
    left join warehouse1 on warehouse1.good_id=goods.id
    left join warehouse2 on warehouse2.good_id=goods.id
    where goods.id = :new.good_id;

    if :new.good_count > sum_count then
        raise_application_error(-20200, 'current good_count to sell more than in both warehouses');
    end if;
end;
/

