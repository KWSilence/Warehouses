create function getGoodsConfrontation(g1 in number, g2 in number)
    return GoodsConfrontation pipelined as
    v_row confrontation;
begin
    for r in(select g1_t.g1_date as "DATE", g1_t.g1_count as "COUNT1", g2_t.g2_count as "COUNT2" from
        (select to_char(sales.create_date, 'dd.mm.yyyy') as g1_date, sum(good_count) as g1_count from sales
        where sales.good_id=g1 group by to_char(sales.create_date, 'dd.mm.yyyy')) g1_t
        join (select to_char(sales.create_date, 'dd.mm.yyyy') as g2_date, sum(good_count) as g2_count from sales
        where sales.good_id=g2 group by to_char(sales.create_date, 'dd.mm.yyyy')) g2_t on g1_t.g1_date = g2_t.g2_date
        where g1_t.g1_count > g2_t.g2_count) loop
        v_row := confrontation(r.date, r.count1, r.count2);
        pipe row (v_row);
    end loop;
    return;
end;
/

