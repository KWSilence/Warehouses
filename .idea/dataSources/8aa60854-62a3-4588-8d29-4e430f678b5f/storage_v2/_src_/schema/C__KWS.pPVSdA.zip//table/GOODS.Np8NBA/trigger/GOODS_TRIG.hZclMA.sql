create trigger GOODS_TRIG
    before insert
    on GOODS
    for each row
    when (NEW.ID IS NULL)
BEGIN
    SELECT GOODS_SEQ.nextval INTO :NEW.ID FROM dual;
END;
/

