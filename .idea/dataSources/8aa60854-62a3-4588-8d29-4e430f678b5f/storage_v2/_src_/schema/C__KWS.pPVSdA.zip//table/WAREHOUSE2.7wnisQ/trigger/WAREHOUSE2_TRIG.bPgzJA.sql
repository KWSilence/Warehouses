create trigger WAREHOUSE2_TRIG
    before insert
    on WAREHOUSE2
    for each row
    when (NEW.ID IS NULL)
BEGIN
    SELECT WAREHOUSE2_SEQ.nextval INTO :NEW.ID FROM dual;
END;
/

