create trigger CHECKWAREHOUSE2
    before update
    on WAREHOUSE2
    for each row
declare
    w1_count number;
begin
    select coalesce(warehouse1.good_count,0) into w1_count from goods
    left join warehouse1 on warehouse1.good_id=goods.id
    where goods.id= :new.good_id;

    if (w1_count > 0 and :new.good_count < :old.good_count) then
        raise_application_error(-20200, 'this good stored in warehouse1');
    end if;
end;
/

