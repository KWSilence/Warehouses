create type forecast as object
("DAY" number,
request number);
/

