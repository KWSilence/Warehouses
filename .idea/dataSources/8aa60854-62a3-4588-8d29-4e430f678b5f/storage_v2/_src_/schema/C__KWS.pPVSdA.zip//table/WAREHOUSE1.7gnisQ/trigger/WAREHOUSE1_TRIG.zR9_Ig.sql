create trigger WAREHOUSE1_TRIG
    before insert
    on WAREHOUSE1
    for each row
    when (NEW.ID IS NULL)
BEGIN
    SELECT WAREHOUSE1_SEQ.nextval INTO :NEW.ID FROM dual;
END;
/

