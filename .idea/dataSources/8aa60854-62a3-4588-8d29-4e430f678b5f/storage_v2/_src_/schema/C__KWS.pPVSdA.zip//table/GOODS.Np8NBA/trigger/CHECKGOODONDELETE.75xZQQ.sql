create trigger CHECKGOODONDELETE
    before delete
    on GOODS
    for each row
declare
    w1_count number;
    w2_count number;
    s_count number;
begin
    select count(*) into w1_count from warehouse1 where good_id = :old.id;
    select count(*) into w2_count from warehouse2 where good_id = :old.id;
    select count(*) into s_count from sales where good_id = :old.id;

    if w1_count > 0 then
        raise_application_error(-20200, 'this good has record on warehouse1');
    end if;
    if w2_count > 0 then
        raise_application_error(-20200, 'this good has record on warehouse2');
    end if;
    if s_count > 0 then
        raise_application_error(-20200, 'this good has record on sales');
    end if;
end;
/

