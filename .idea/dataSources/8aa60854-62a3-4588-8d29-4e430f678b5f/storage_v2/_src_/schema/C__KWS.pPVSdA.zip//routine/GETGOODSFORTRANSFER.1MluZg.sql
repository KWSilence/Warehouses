create function getGoodsForTransfer return GoodsTransfer pipelined as
    v_row transfer;
begin
    for r in (select goods.id, goods.name, sum(sales.good_count) as count from goods
        join sales on sales.good_id=goods.id
        where create_date between to_date(to_char(sysdate-1, 'dd.mm.yyyy')) and sysdate  --[now-1 00:00; now)
        group by goods.id, goods.name, goods.priority
        order by goods.priority desc) loop
            v_row := transfer (r.id, r.name, r.count);
            pipe row (v_row);
        end loop;
    return;
end;
/

