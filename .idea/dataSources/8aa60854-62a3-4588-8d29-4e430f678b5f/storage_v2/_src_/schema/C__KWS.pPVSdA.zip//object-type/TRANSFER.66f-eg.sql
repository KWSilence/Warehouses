create TYPE transfer AS object
(id number,
name varchar2(50),
count number);
/

