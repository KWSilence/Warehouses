create view VIEW2 as
select goods.name, sum(good_count) as "count" from goods
join sales on goods.id = sales.good_id
where extract(month from create_date) = '02'
group by goods.id, goods.name
order by sum(good_count) desc
FETCH NEXT 5 ROWS ONLY
/

