create function getGoodsForTransfer1(g_count in number) 
    return GoodsTransfer pipelined as
    cur_count number := 0;
    v_row transfer;
begin
    for rec in (select * from table ( getGoodsForTransfer )) loop
        if ((cur_count+ rec.count) >= g_count) then
            v_row := transfer(rec.id, rec.name, g_count-cur_count);
            pipe row (v_row);
            return;
        end if;
        v_row := transfer(rec.id, rec.name, rec.count);
        pipe row (v_row);
        cur_count := cur_count + rec.count;
    end loop;
    return;
end;
/

